from shape import Shape

class Triangle(Shape):
    """This class implements the functionality for an equilateral triangle.

    Attributes:
        name (str): A name associated with the triangle, is inherited from Shape
        length (float): the length of the sides of the triangle
    """

    def __init__(self, name, length):
        pass

    def __len__(self):
        pass

    def perimeter(self):
        """Returns the perimeter of of the triangle"""
        pass

    def area(self):
        """Returns the area of of the triangle"""
        pass

    def from_shape(self, shape):
        """Returns a triangle that has the same area as the shape argument

        This function creates a new triangle object that has the same area as
        a the given `shape` argument. i.e.

        new_triangle.area() == shape.area()

        args:
            shape (Shape): A subclass of the Shape class.

        returns:
            A triangle object that has the same area as the `shape` argument
        """
        pass


if __name__=="__main__":
    pass
    # you can do some testing here and then run them using:
    # python triangle.py