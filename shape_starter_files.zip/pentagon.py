from shape import Shape

class Pentagon(Shape):
    """This class implements the functionality for an equilateral pentagon.

    Attributes:
        name (str): A name associated with the pentagon, is inherited from Shape
        length (float): the length of the sides of the pentagon
        apothem (float): the distance from the center of the pentagon to a side
    """

    def __init__(self, name, length, apothem):
        pass

    def __len__(self):
        pass

    def perimeter(self):
        """Returns the perimeter of of the pentagon"""
        pass

    def area(self):
        """Returns the area of of the pentagon"""
        pass

    def from_shape(self, shape):
        """Returns a pentagon that has the same area as the shape argument

        This function creates a new pentagon object that has the same area as
        a the given `shape` argument. i.e.

        new_pentagon.area() == shape.area()

        args:
            shape (Shape): A subclass of the Shape class.

        returns:
            A pentagon object that has the same area as the `shape` argument
        """
        pass



if __name__=="__main__":
    pass
    # you can do some testing here and then run them using:
    # python pentagon.py