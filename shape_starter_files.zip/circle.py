from shape import Shape

class Circle(Shape):
    """This class implements the functionality for an circle.

    Attributes:
        name (str): A name associated with the circle, is inherited from Shape
        radius (float): the length of the radius for the circle
    """

    def __init__(self, name, radius):
        pass

    def __len__(self):
        """Returns the number of sides in the shape"""
        pass

    def perimeter(self):
        """Returns the perimeter of of the circle"""
        pass

    def area(self):
        """Returns the area of of the circle"""
        pass

    def from_shape(self, shape):
        """Returns a circle that has the same area as the shape argument

        This function creates a new circle object that has the same area as
        a the given `shape` argument. i.e.

        new_circle.area() == shape.area()

        args:
            shape (Shape): A subclass of the Shape class.

        returns:
            A circle object that has the same area as the `shape` argument
        """
        pass



if __name__=="__main__":
    pass
    # you can do some testing here and then run them using:
    # python circle.py