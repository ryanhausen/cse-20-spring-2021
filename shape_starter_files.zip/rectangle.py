from shape import Shape


class Rectangle(Shape):
    """This class implements the functionality for an rectangle.

    Attributes:
        name (str): A name associated with the rectangle, is inherited from Shape
        length (float): the length of one of the sides of the rectangle
        width (float): the lengthe of the other sides of the rectangle
    """

    def __init__(self, name, length, width):
        pass

    def __len__(self):
        pass

    def perimeter(self):
        """Returns the perimeter of of the rectangle"""
        pass

    def area(self):
        """Returns the area of of the rectangle"""
        pass

    def from_shape(self, shape):
        """Returns a rectangle that has the same area as the shape argument

        This function creates a new rectangle object that has the same area as
        a the given `shape` argument. i.e.

        new_rectangle.area() == shape.area()

        args:
            shape (Shape): A subclass of the Shape class.

        returns:
            A rectangle object that has the same area as the `shape` argument
        """
        pass


if __name__=="__main__":
    pass
    # you can do some testing here and then run them using:
    # python rectangle.py