from shape import Shape

class Square(Shape):
    """This class implements the functionality for an square.

    Attributes:
        name (str): A name associated with the square, is inherited from Shape
        width (float): the length of the sides of the square
    """

    def __init__(self, name, width):
        pass

    def __len__(self):
        pass

    def perimeter(self):
        """Returns the perimeter of of the square"""
        pass

    def area(self):
        """Returns the area of of the square"""
        pass

    def from_shape(self, shape):
        """Returns a square that has the same area as the shape argument

        This function creates a new square object that has the same area as
        a the given `shape` argument. i.e.

        new_square.area() == shape.area()

        args:
            shape (Shape): A subclass of the Shape class.

        returns:
            A square object that has the same area as the `shape` argument
        """
        pass


if __name__=="__main__":
    pass
    # you can do some testing here and then run them using:
    # python square.py