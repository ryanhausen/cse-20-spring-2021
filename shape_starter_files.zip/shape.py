

class Shape:
    """A base class for all other shapes.

    This class is not intended to be used, rather it is intended to be a base 
    class for all other shapes.

    Attributes:
        name (str): The name associated with the shape object
    """

    def __init__(self, name):
        pass

    def perimeter(self):
        """Returns the perimeter of of the shape.
        
        SHOULD RAISE NOT IMPLEMENTED ERROR

        """
        pass

    def area(self):
        """Returns the area of of the shape.
        
        SHOULD RAISE NOT IMPLEMENTED ERROR

        """
        pass

    def from_shape(self, shape):
        """Returns a shape with the same area as the `shape` argument.
        
        SHOULD RAISE NOT IMPLEMENTED ERROR

        """
        pass


if __name__=="__main__":
    pass
    # you can do some testing here and then run them using:
    # python shape.py