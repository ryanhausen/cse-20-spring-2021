from account import Account, Transaction
import user_interface as ui
import storage 


def main_v2():
    ui.print_starting_banner()

    acct_number = int(float(ui.get_account_number()))

    account = storage.get_account(acct_number)

    prev_balance = account.balance

    new_transactions = ui.get_new_transactions()
    for t_type, amount in new_transactions:
        account.add_transaction(Transaction(t_type, amount))

    ui.print_statement_banner(prev_balance)
    
    ui.print_new_transactions(prev_balance, new_transactions)

    ui.print_closing_banner(account.balance)

    storage.save_account(account)

def main():
    transactions = storage.get_transactions()

    ui.print_starting_banner()

    if len(transactions) == 0:
        current_balance = ui.get_decimal_input("Enter your balance: $")
        transactions.append(("d", current_balance))
    else:
        current_balance = 0
        for t_type, amt in transactions:
            if t_type == "d":
                current_balance  += amt
            else:
                current_balance -= amt


    new_balance = current_balance

    new_transactions = ui.get_new_transactions()

    ui.print_statement_banner(current_balance)

    new_balance = ui.print_new_transactions(new_balance, new_transactions)

    ui.print_closing_banner()

    storage.save_transactions(new_transactions)    


if __name__=="__main__":
    main_v2()