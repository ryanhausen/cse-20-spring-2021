
class Transaction:
    TYPE_DEPOSIT = "d"
    TYPE_WITHDRAWAL = "w"

    def __init__(self, t_type, amount):
        self.t_type = t_type
        self.amount = amount

class Account:

    def __init__(self, number, balance=0, transactions=[]):
        self.number = number
        self.balance = balance
        self.transactions = []

    def add_transaction(self, transaction):

        if transaction.t_type == Transaction.TYPE_DEPOSIT:
            self.balance += transaction.amount
        else:
            self.balance -= transaction.amount

        self.transactions.append(transaction)

