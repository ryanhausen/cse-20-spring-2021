import os
import pickle

from account import Account

def get_account(acct_number):

    acc_file = f"{acct_number}.pkl"
    if os.path.exists(acc_file): 
        with open(acc_file, "rb") as f:
            return pickle.load(f)

    else:
        return Account(int(acct_number))


def save_account(account):

    with open(f"{account.number}.pkl", "wb") as f:
        pickle.dump(account, f)





FILE_NAME = "transactions.csv"

def get_transactions():

    if os.path.exists(FILE_NAME):
        transactions = []
        with open(FILE_NAME, "r") as f:
            next(f) # skip header
            for line in f:
                t_type, amt = line.strip().split(",")
                transactions.append(
                    (t_type,float(amt))
                )
        return transactions
    else:
        return []


def save_transactions(new_transactions):

    if os.path.exists(FILE_NAME):
        open_mode = "a"
    else:
        open_mode = "w"

    with open(FILE_NAME, open_mode) as f:

        if open_mode == "w":
            f.write("transaction_type,amount\n")

        for t in new_transactions:
            f.write(f"{t[0]},{t[1]}" + "\n")
