

green = lambda s:"\033[32m {}\033[00m" .format(s)

def is_valid_number(num_str):
    return set(num_str).issubset(set("0123456789.")) and num_str.count(".")<2

def get_decimal_input(msg):
    user_input = input(msg)
    
    while not is_valid_number(user_input):
        user_input = input(msg)
        
    return float(user_input)

def get_valid_string_input(msg, valid_values):
    user_input = input(msg).lower()
    
    while user_input not in valid_values:
        user_input = input(msg).lower()
    
    return user_input


def print_starting_banner():
    print(green("$" * 50))
    print("{:^50}".format("Welcome to Slug Money"))
    print(green("$" * 50))


def print_statement_banner(starting_balance):
    print("{:=^50}".format("Statement"))
    print("Your starting balance was: ${:.2f}".format(starting_balance))
    print("{:>40}{:>10}".format("Transaction Amount", "Balance"))


def print_closing_banner(ending_balance):
    print("Your ending balance is: ${:.2f}".format(ending_balance))
    print("Thanks for using Slug Money!")


def get_new_transactions():
    new_transactions = []

    transaction_msg = "Transaction type:(d)eposit, (w)ithdrawal, (q)uit:"
    t_type = get_valid_string_input(transaction_msg, ["d", "w", "q"])

    while t_type != "q":
        transaction_amount = get_decimal_input("Enter transaction amount: $")
        new_transactions.append((t_type, transaction_amount))
        
        t_type = get_valid_string_input(transaction_msg, ["d", "w", "q"])

    return new_transactions


def print_new_transactions(new_balance, new_transactions):
    for t_type, amount in new_transactions:
        if t_type=="d":
            new_balance += amount
            amount_str = "{:.2f}".format(amount)
        else:
            new_balance -= amount
            amount_str = "({:.2f})".format(amount)
            
        print("{:>40}{:>10.2f}".format(amount_str, new_balance))

    return new_balance


def get_account_number():
    msg = "Enter account number:"
    acct_number = get_decimal_input(msg)
    return str(acct_number)