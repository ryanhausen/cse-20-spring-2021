# The random module provides loads of functions
# for making random numbers/choices - this is useful for games, algorithms
# and machine learning where stochastic behaviour is needed

import random as r

def make_random_ints(num, lower_bound, upper_bound):
    """
    Generate a list containing num random ints between lower_bound
    and upper_bound. upper_bound is an open bound.
    """
    rng = r.Random()  # Create a random number generator

    # Makes a sequence of random numbers using rng.randrange()
    return [rng.randrange(lower_bound, upper_bound) for _ in range(num)]

res = make_random_ints(5, 0, 6) # Make a sequence of 10 random numbers, each in
# the interval (0 6]
print(res)