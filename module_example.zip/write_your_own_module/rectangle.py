# This module has functions that help calculate aspects of a rectangle

def area(length, width):
    """Calculates the area of a rectangle with a given `length` and `width`

    args:
        length (int): the length the rectangle
        width (int): the width the rectangle

    returns
        the area
    """

    return length * width


def perimeter(length, width):
    """Calculates the perimeter of a rectangle with a given `length` and `width`

    args:
        length (int): the length the rectangle
        width (int): the width the rectangle

    returns
        the perimeter
    """

    return 2 * (length + width)
