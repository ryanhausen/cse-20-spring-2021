import rectangle as rect


def main():
    l = 5
    w = 5
    print("The area is", rect.area(l, w))

    print("The perimeter is", rect.perimeter(l, w))

if __name__=="__main__":
    main()

