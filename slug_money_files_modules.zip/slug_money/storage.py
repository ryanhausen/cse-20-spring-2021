import os

FILE_NAME = "transactions.csv"

def get_transactions():

    if os.path.exists(FILE_NAME):
        transactions = []
        with open(FILE_NAME, "r") as f:
            next(f) # skip header
            for line in f:
                t_type, amt = line.strip().split(",")
                transactions.append(
                    (t_type,float(amt))
                )
        return transactions
    else:
        return []


def save_transactions(new_transactions):

    if os.path.exists(FILE_NAME):
        open_mode = "a"
    else:
        open_mode = "w"

    with open(FILE_NAME, open_mode) as f:

        if open_mode == "w":
            f.write("transaction_type,amount\n")

        for t in new_transactions:
            f.write(f"{t[0]},{t[1]}" + "\n")
