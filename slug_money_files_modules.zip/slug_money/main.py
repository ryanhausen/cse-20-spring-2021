import user_interface as ui
import storage 


def main():
    transactions = storage.get_transactions()

    ui.print_starting_banner()

    if len(transactions) == 0:
        current_balance = ui.get_decimal_input("Enter your balance: $")
        transactions.append(("d", current_balance))
    else:
        current_balance = 0
        for t_type, amt in transactions:
            if t_type == "d":
                current_balance  += amt
            else:
                current_balance -= amt


    new_balance = current_balance

    new_transactions = ui.get_new_transactions()

    ui.print_statement_banner(current_balance)

    new_balance = ui.print_new_transactions(new_balance, new_transactions)

    ui.print_closing_banner(new_balance)

    storage.save_transactions(new_transactions)    


if __name__=="__main__":
    main()